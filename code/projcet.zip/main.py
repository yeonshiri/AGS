import os
from pathlib import Path
from roi import extract_roi_and_split
from detector import run_yolo_detect,parse_yolo_label
from ocr import extract_texts_from_cropped_answers

from utils import capture_exam_images, compare_dictionary, load_answer_key, cleanup_directories
from grading.subjective import extract_texts_from_cropped_answers
from grading.objective import predict_answer_objective_dict



# 설정 경로
RAW_IMAGE_DIR = "input/raw_images"
OBJ_IMAGE_DIR = "input/objective"
SUBJ_IMAGE_DIR = "input/subjective"
ANSWER_KEY_PATH = "data/answer_key.json"




def main():
    # 1. 시험지 촬영
    image_dir = capture_exam_images()

    # 2. ROI 추출 및 분리
    obj_dir, subj_dir = extract_roi_and_split(image_dir)

    # 3. 정답 불러오기
    answer_key = load_answer_key(ANSWER_KEY_PATH)

    # 4. YOLO detect
    print("\n🚀 YOLO detect 시작")
    label_dir_obj, _ = run_yolo_detect(
    weights_path="weights/option_box.pt",
    image_dir="input/objective", 
    img_size=640,
    conf=0.25,
    save_crop=False,
    name="objective_detect"
    )

    # 예: 주관식 답변 영역 탐지 (crop도 필요)
    _, label_subj = run_yolo_detect(
    weights_path="weights/answer_box.pt",
    image_dir="input/subjective", 
    img_size=640,
    conf=0.25,
    save_crop=True,
    name="answerbox_detect"
    )  

    # 5 객관관식 답
    student_answers = predict_answer_objective_dict(label_dir_obj)
    student_answers.update(extract_texts_from_cropped_answers(label_subj))
    # 6. 채점
    print("\n📝 채점 시작")
    final_score = compare_dictionary(answer_key, student_answers)

    # 7. 사용자 확인 후 초기화
    confirm = input("채점 완료. 이미지 데이터를 삭제할까요? (y/n): ")
    if confirm.lower() == "y":
        cleanup_directories([image_dir, obj_dir, subj_dir])
        print("이미지 초기화 완료.")

if __name__ == "__main__":
    main()
